import React from 'react';
import { toast } from '@/hooks/use-toast';
import steelManufacturing from '../assets/steel-manufacturing.jpg';
import lrfOptimization from '../assets/lrf-optimization.jpg';
import pharmaInventory from '../assets/pharma-inventory.jpg';
import tataAnalytics from '../assets/tata-analytics.jpg';
const Portfolio = () => {
  const skills = [
    { name: 'SQL', category: 'Database' },
    { name: 'Python', category: 'Programming' },
    { name: 'Power BI', category: 'Visualization' },
    { name: 'Tableau', category: 'Visualization' },
    { name: 'Excel', category: 'Analysis' },
    { name: 'Pandas', category: 'Programming' },
    { name: 'NumPy', category: 'Programming' },
    { name: 'Matplotlib', category: 'Visualization' },
  ];

  const projects = [
    {
      title: "Steel Manufacturing Process Optimization",
      description: "Analyzed production data to optimize steel manufacturing processes, achieving 20% reduction in processing time and $1M+ annual cost savings.",
      tech: ["Python", "SQL", "Power BI", "EDA"],
      client: "AISPRY",
      duration: "Feb 2025 - Mar 2025",
      image: steelManufacturing
    },
    {
      title: "LRF Process Optimization",
      description: "Optimized Ladle Refining Furnace processes using data analytics to improve yield and reduce material waste through strategic sampling frequency optimization.",
      tech: ["Python", "SQL", "Power BI", "Process Mining"],
      client: "AISPRY",
      duration: "Apr 2025 - May 2025",
      image: lrfOptimization
    },
    {
      title: "Pharmaceutical Inventory Optimization",
      description: "Analyzed procurement and inventory data to reduce inventory levels by 20% and storage costs by 25% while maximizing stock utilization.",
      tech: ["Python", "SQL", "Excel", "Power BI"],
      client: "AISPRY",
      duration: "May 2025 - Jun 2025",
      image: pharmaInventory
    },
    {
      title: "Tata Group Data Analytics Simulation",
      description: "Completed AI-powered data analytics job simulation focusing on customer delinquency risk assessment using GenAI tools and predictive modeling.",
      tech: ["GenAI", "EDA", "Predictive Modeling", "Risk Analysis"],
      client: "Tata iQ",
      duration: "Jun 2025",
      image: tataAnalytics
    }
  ];

  const socialLinks = [
    { name: 'LinkedIn', href: 'https://www.linkedin.com/', icon: '💼' },
    { name: 'GitHub', href: 'https://github.com/', icon: '🔗' },
    { name: 'Email', href: 'mailto:aravindbattini1800@gmail.com', icon: '📧' },
    { name: 'Portfolio', href: '#home', icon: '🌐' },
  ];

  const handleSubmit: React.FormEventHandler<HTMLFormElement> = (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    const name = String(formData.get('name') || '');
    const email = String(formData.get('email') || '');
    const message = String(formData.get('message') || '');
    const subject = encodeURIComponent(`Portfolio Contact from ${name || 'Visitor'}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`);
    const mailto = `mailto:aravindbattini1800@gmail.com?subject=${subject}&body=${body}`;
    toast({ title: 'Opening your email app...', description: 'If nothing happens, email me at aravindbattini1800@gmail.com' });
    window.location.href = mailto;
    form.reset();
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 glass border-b border-glass-border backdrop-blur-md">
        <div className="container mx-auto px-4 sm:px-6 py-3 sm:py-4">
          <div className="flex justify-between items-center">
            <div className="text-lg sm:text-xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              BA
            </div>
            <div className="hidden md:flex space-x-6 lg:space-x-8">
              <a href="#home" className="nav-link text-sm lg:text-base">Home</a>
              <a href="#about" className="nav-link text-sm lg:text-base">About</a>
              <a href="#projects" className="nav-link text-sm lg:text-base">Projects</a>
              <a href="#resume" className="nav-link text-sm lg:text-base">Resume</a>
              <a href="#contact" className="nav-link text-sm lg:text-base">Contact</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center animated-bg px-4 sm:px-6 pt-16 sm:pt-20">
        <div className="text-center max-w-4xl mx-auto">
          <div className="animate-fade-in-up">
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent leading-tight">
              BATHINI ARAVIND
            </h1>
          </div>
          <div className="animate-fade-in-up delay-200">
            <h2 className="text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl font-medium mb-6 sm:mb-8 text-muted-foreground">
              Data Analyst & Business Intelligence Specialist
            </h2>
          </div>
          <div className="animate-fade-in-up delay-300">
            <p className="text-sm sm:text-base md:text-lg lg:text-xl text-muted-foreground mb-6 sm:mb-8 max-w-2xl mx-auto leading-relaxed px-4">
              Transforming complex datasets into actionable insights. Specialized in SQL, Python, Power BI, and Tableau 
              with a passion for data-driven strategies that drive business growth and innovation.
            </p>
          </div>
          <div className="animate-fade-in-up delay-400 flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center px-4">
            <a href="#projects" className="btn-primary px-6 sm:px-8 py-3 sm:py-4 rounded-lg transition-all duration-300 text-sm sm:text-base">
              View My Work
            </a>
            <a href="#contact" className="btn-secondary px-6 sm:px-8 py-3 sm:py-4 rounded-lg transition-all duration-300 text-sm sm:text-base">
              Get In Touch
            </a>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 sm:py-20 px-4 sm:px-6">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              About Me
            </h2>
            <p className="text-base sm:text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto px-4">
              A highly motivated Data Analyst with expertise in transforming complex datasets into actionable insights 
              that enhance decision-making and drive business success.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 items-center">
            <div className="animate-slide-in-left">
              <div className="glass-card">
                <h3 className="text-xl sm:text-2xl font-semibold mb-4 sm:mb-6 text-primary">Professional Summary</h3>
                <div className="space-y-3 sm:space-y-4 text-sm sm:text-base text-muted-foreground">
                  <p>
                    🎯 Specializes in data analysis, business intelligence, and data visualization
                  </p>
                  <p>
                    💡 Skilled in transforming complex datasets into actionable insights
                  </p>
                  <p>
                    📈 Successfully delivered projects with cost-saving opportunities and improved efficiency
                  </p>
                  <p>
                    🚀 Passionate about leveraging data-driven strategies for business growth
                  </p>
                </div>
              </div>
            </div>

            <div className="animate-slide-in-right">
              <div className="glass-card">
                <h3 className="text-xl sm:text-2xl font-semibold mb-4 sm:mb-6 text-secondary">Skills & Expertise</h3>
                <div className="grid grid-cols-2 gap-2 sm:gap-3">
                  {skills.map((skill, index) => (
                    <div
                      key={skill.name}
                      className={`skill-badge animate-fade-in-up delay-${index * 100}`}
                    >
                      <div className="text-center">
                        <div className="text-xs sm:text-sm font-medium text-foreground">{skill.name}</div>
                        <div className="text-xs text-muted-foreground">{skill.category}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-6 bg-gradient-to-b from-slate-900/20 to-slate-800/20">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-cyan-400 to-teal-400 bg-clip-text text-transparent">
              Featured Projects
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Real-world data analytics projects that delivered measurable business impact and operational improvements.
            </p>
          </div>

          <div className="grid sm:grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
            {projects.map((project, index) => (
              <div
                key={project.title}
                className={`project-card animate-fade-in-up delay-${index * 200} overflow-hidden`}
              >
                <div className="relative h-48 sm:h-56 mb-4 overflow-hidden rounded-lg">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent"></div>
                </div>
                <div className="p-4 sm:p-6">
                  <div className="mb-4">
                    <h3 className="text-lg sm:text-xl font-semibold text-foreground mb-2">{project.title}</h3>
                    <div className="text-xs sm:text-sm text-muted-foreground mb-3">
                      <span className="text-accent">{project.client}</span> • {project.duration}
                    </div>
                  </div>
                  <p className="text-sm sm:text-base text-muted-foreground mb-6 leading-relaxed">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.tech.map((tech) => (
                      <span
                        key={tech}
                        className="px-2 sm:px-3 py-1 text-xs rounded-full bg-gradient-to-r from-primary/20 to-secondary/20 border border-primary/30 text-primary-foreground"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Resume Section */}
      <section id="resume" className="py-20 px-6">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
            Resume
          </h2>
          <p className="text-xl text-gray-400 mb-12">
            Download my complete resume to learn more about my experience and qualifications.
          </p>
          
          <div className="glass-card max-w-md mx-auto">
            <div className="text-6xl mb-6">📄</div>
            <h3 className="text-xl font-semibold text-white mb-4">Full Resume</h3>
            <p className="text-gray-400 mb-6">
              Complete overview of my experience, education, and achievements in data analytics.
            </p>
            <a
              href="#"
              className="btn-accent px-8 py-3 rounded-lg transition-all duration-300 inline-block"
            >
              Download PDF
            </a>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6 bg-gradient-to-b from-slate-900/20 to-slate-800/20">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
              Get In Touch
            </h2>
            <p className="text-xl text-gray-400">
              Ready to transform your data into actionable insights? Let's discuss your project.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div className="animate-slide-in-left">
              <div className="glass-card">
                <h3 className="text-2xl font-semibold mb-6 text-white">Contact Information</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="text-2xl">📍</div>
                    <div>
                      <div className="font-medium text-white">Location</div>
                      <div className="text-gray-400">Karimnagar, India</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-2xl">📞</div>
                    <div>
                      <div className="font-medium text-white">Phone</div>
                      <div className="text-gray-400">+91 8328194891</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-2xl">📧</div>
                    <div>
                      <div className="font-medium text-white">Email</div>
                      <div className="text-gray-400">aravindbattini1800@gmail.com</div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8">
                  <h4 className="text-lg font-medium text-white mb-4">Follow Me</h4>
                  <div className="flex space-x-4">
                    {socialLinks.map((social) => (
                      <a
                        key={social.name}
                        href={social.href}
                        className="social-icon"
                        title={social.name}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <span className="text-xl">{social.icon}</span>
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="animate-slide-in-right">
              <div className="glass-card">
                <h3 className="text-2xl font-semibold mb-6 text-white">Send Message</h3>
                <form className="space-y-6" onSubmit={handleSubmit}>
                  <div>
                    <input
                      type="text"
                      name="name"
                      placeholder="Your Name"
                      className="glass-input w-full"
                      required
                      aria-label="Your Name"
                    />
                  </div>
                  <div>
                    <input
                      type="email"
                      name="email"
                      placeholder="Your Email"
                      className="glass-input w-full"
                      required
                      aria-label="Your Email"
                    />
                  </div>
                  <div>
                    <textarea
                      name="message"
                      placeholder="Your Message"
                      rows={5}
                      className="glass-input w-full resize-none"
                      required
                      aria-label="Your Message"
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="btn-primary w-full py-4 rounded-lg transition-all duration-300"
                    aria-label="Send Message"
                  >
                    Send Message
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-white/10">
        <div className="container mx-auto text-center">
          <p className="text-gray-400">
            © 2025 Bathini Aravind. All rights reserved.
          </p>
          <p className="text-sm text-gray-500 mt-2">
            Built with passion for data and innovation
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Portfolio;